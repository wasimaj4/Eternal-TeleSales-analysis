from pyspark.sql import SparkSession
from chispa.dataframe_comparer import *
from src.analysis.it_data import it_data

spark = (SparkSession.builder
         .master("local")
         .appName("")
         .getOrCreate())
spark.driver.extraJavaOptions

def test_it_data():

    personal_data = [
        (1, "John Doe", "123 Main St", 5000),
        (2, "Jane Smith", "456 Elm St", 4000),
        (3, "Bob Johnson", "789 Oak St", 6000),
        (4, "Alice Brown", "321 Pine St", 5500),
        (5, "Charlie Davis", "654 Maple St", 5200),
        (6, "Eva Wilson", "987 Cedar St", 5800),
        (7, "Frank Miller", "654 Birch St", 4800),
        (8, "Grace Lee", "321 Walnut St", 5100)
    ]

    personal_schema = ["id", "name", "address", "sales_amount"]
    df_personal = spark.createDataFrame(personal_data, schema=personal_schema)

    work_info_data = [
        (1, "Marketing", 100, 80),
        (2, "IT", 50, 40),
        (3, "Marketing", 80, 70),
        (4, "Finance", 70, 60),
        (5, "IT", 90, 85),
        (6, "Marketing", 120, 90),
        (7, "Finance", 60, 50),
        (8, "IT", 80, 70),
    ]

    work_info_schema = ["id", "area", "calls_made", "calls_successful"]
    df_work_info = spark.createDataFrame(work_info_data, schema=work_info_schema)

    actual_df = it_data(df_work_info, df_personal)

    expected_data = [
        (5, "IT", 90, 85, "Charlie Davis","654 Maple St", 5200),
        (8, "IT", 80, 70, "Grace Lee", "321 Walnut St", 5100),
        (2, "IT", 50, 40, "Jane Smith", "456 Elm St", 4000)
    ]

    expected_schema = ["id", "area", "calls_made", "calls_successful", "name", "address", "sales_amount"]
    expected_df = spark.createDataFrame(expected_data, schema=expected_schema)

    expected_df.show(3)
    actual_df.show(3)

    assert_df_equality(actual_df, expected_df) # exact match
    assert_schema_equality(actual_df.columns , expected_schema)