import logging
from logging.handlers import TimedRotatingFileHandler


def create_timed_rotating_log(path):
    """"""
    get_logger = logging.getLogger("Rotating Log")
    get_logger.setLevel(logging.INFO)

    handler = TimedRotatingFileHandler(path,
                                       when="m",
                                       interval=1,
                                       backupCount=5)
    get_logger.addHandler(handler)

    return get_logger

logger = create_timed_rotating_log("../logs/current_log.log")