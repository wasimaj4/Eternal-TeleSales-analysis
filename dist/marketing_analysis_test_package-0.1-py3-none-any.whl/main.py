from pyspark.sql import SparkSession
from analysis.it_data import it_data
from analysis.marketing_address_info import marketing_address_info
from analysis.department_breakdown import department_breakdown
from analysis.top_3 import top_3
from analysis.top_3_most_sold_per_department_nl import top_3_most_sold_per_department_netherlands
from analysis.best_salesperson import best_salesperson
from analysis.extra_insight_one import extra_insight_one
from analysis.extra_insight_two import extra_insight_two


def analysis(prod_info: str, seller_info: str, buyer_info: str):

    spark = SparkSession.builder.appName("EternaAnalysis").getOrCreate()
    df_work_info = spark.read.option("header", True).csv(prod_info)
    df_personal = spark.read.option("header", True).csv(seller_info)
    df_product = spark.read.option("header", True).csv(buyer_info)


   # Call feature functions
    logging.info("Processing IT data...")
    it_df = it_data(df_work_info, df_personal)
    logging.info("Processing Marketing address info...")
    marketing_df = marketing_address_info(df_work_info, df_personal)
    logging.info("Processing department sales breakdown...")
    sales_breakdown_df = department_breakdown(df_work_info, df_personal)
    logging.info("Identifying top 3 employees by performance...")
    top_employees_df = top_3(df_work_info, df_personal)
    logging.info("Fetching top 3 most sold products in the Netherlands...")
    top_products_nl_df = top_3_most_sold_per_department_netherlands(df_work_info, df_product)
    logging.info("Finding the best salesperson by country...")
    best_salesperson_df = best_salesperson(df_personal, df_product)
    logging.info("Generating extra insight one (Area Efficiency)...")
    area_efficiency_df = extra_insight_one(df_work_info, df_product)
    logging.info("Generating extra insight two (Customer Loyalty)...")
    customer_loyalty_df = extra_insight_two(df_work_info,df_personal, df_product)
    logging.info("Application processing complete.")

    # Optionally: Return or display results
    return (it_df, marketing_df, sales_breakdown_df, top_employees_df,
            top_products_nl_df, best_salesperson_df, area_efficiency_df, customer_loyalty_df)


if __name__ == "__main__":
    logging.info("Launching the application...")
    file1 = "data_sets/dataset_one.csv"
    file2 = "data_sets/dataset_two.csv"
    file3 = "data_sets/dataset_three.csv"
    analysis(file1, file2, file3)
    logging.info("Eterna Analysis application finished execution.")